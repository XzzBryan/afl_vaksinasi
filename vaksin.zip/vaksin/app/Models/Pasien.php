<?php

namespace App\Models;

use App\Models\Vaksin;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Pasien extends Model
{
    use HasFactory;

    protected $fillable = ['pasien_name', 'penyuntik', 'jumlah', 'nama_vaksin', 'gejala', 'deskripsi'];
    protected $table = 'pasiens';

    public function Vaksin()
    {
       return $this->belongsTo(Vaksin::class);
    }

}
