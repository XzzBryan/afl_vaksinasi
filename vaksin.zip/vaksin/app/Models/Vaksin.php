<?php

namespace App\Models;

use App\Models\Pasien;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Vaksin extends Model
{
    use HasFactory;

    protected $fillable = ['code', 'vaksin_name', 'efektifitas', 'pembuat', 'deskripsi'];
    protected $table = 'vaksins';

    public function Pasien()
    {
       return $this->hasMany(Pasien::class);
    }
    
}
