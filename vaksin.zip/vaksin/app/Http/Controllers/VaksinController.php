<?php

namespace App\Http\Controllers;
use Illuminate\Support\Str;
use App\Models\vaksin;

use Illuminate\Http\Request;

class VaksinController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        return view('vaksin', ['title'=>'Vaksin',
                            'vaksin'=>Vaksin::all()
           ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view('createvaksin', ['title'=>'Create Vaksin']);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $this->validate($request,[
            'vaksin_name' => 'required|min:2|max:20',
        ]);

        vaksin::create([
            'vaksincode' => $request->vaksin_code,
            'code' => $request->code,
            'vaksin_name' => $request->vaksin_name,
            'efektifitas' => $request->efektifitas,
            'pembuat' => $request->pembuat,
            'deskripsi' => $request->deskripsi
        ]);
        return redirect(route('vaksin.index'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($code)
    {
        //
        $vaksin = vaksin::where('code', $code)->first();
        return view('showvaksin', [
            'title'=>'Vaksin Details',
            'vaksin'=>$vaksin
        ]);

        return redirect(route('vaksin.index'));

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $vaksin = vaksin::findorFail($id);
        return view('editvaksin', [
            'title'=>'Edit Vaksin',
            'vaksin'=>$vaksin
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $code = (Str::substr($request->vaksin, 0, 3));  
        $vaksin = vaksin::findorFail($id);
        $vaksin->update([
            'vaksincode'=> $request->vaksincode,
            'code'=> $request->code,
            'vaksin_name'=> $request->vaksinname,
            'efektifitas'=> $request->efektif,
            'pembuat'=> $request->pembuat,
            'deskripsi'=> $request->deskripsi
        ]); 
        return redirect(route('vaksin.index'));

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $vaksin = vaksin::findorFail($id);
        $vaksin->delete();
        return redirect(route('vaksin.index'));
    }
}
