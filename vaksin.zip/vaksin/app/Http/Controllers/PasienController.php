<?php

namespace App\Http\Controllers;

use App\Models\Pasien;
use Illuminate\Support\Str;

use Illuminate\Http\Request;

class PasienController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        return view('pasien', ['title'=>'Pasien',
                           'pasien'=>Pasien::all()
           ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view('createpasien', ['title'=>'Create Pasien']);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
    
        $this->validate($request,[
            'pasien_name' => 'required|min:2|max:50',
        ]);

        //
        $id = (Str::substr($request->pasien,0 , 3));

        Pasien::create([
            'id' => $id,
            'pasien_name' => $request->pasien_name,
            'penyuntik' => $request->penyuntik,
            'jumlah' => $request->jumlah,
            'nama_vaksin' => $request->nama_vaksin,
            'gejala' => $request->gejala,
            'deskripsi' => $request->deskripsi
        ]);
        return redirect(route('pasien.index'));

    }


    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        $pasien = Pasien::where('id', $id)->first();
        return view('showpasien', [
            'title'=>'Pasien Details',
            'pasien'=>$pasien
        ]);

         return redirect(route('pasien.index'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        // $pasien = Pasien::findorFail($id);
        return view('editpasien', [
            'title'=>'Edit Pasien',
            'pasien'=> Pasien::findorFail($id)->first()
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        
        $id = (Str::substr($request->pasien, 0, 3));
        $pasien = Pasien::findorFail($id);
        $pasien->update([
            'id'=> $request->pasiencode,
            'pasien_name'=> $request->pasienname,
            'penyuntik'=> $request->penyuntik,
            'jumlah'=> $request->jumlah,
            'nama_vaksin'=> $request->vaksinname,
            'gejala'=> $request->gejala,
            'deskripsi'=> $request->deskripsi
        ]); 
        return redirect(route('pasien.index'));

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $pasien =Pasien::findorFail($id);
        $pasien->delete();
        return redirect(route('pasien.index'));
    }

}