<?php

use App\Models\pasien;
use App\Http\Controllers\VaksinController;
use App\Http\Controllers\PasienController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::resource('pasien', PasienController::class);

Route::resource('vaksin', VaksinController::class);


Route::get('/', function () {
    return view('home', ['title'=>'Home',
                         'image'=>'earthimgbg.jpg']);
});

Route::get('/about', function () {
    return view('about', ['title'=>'About',
                          'image'=>'vaksinkartun.png']);
});

// Route::get('/vaksin', function () {
//     return view('vaksin', ['title'=>'Vaksin',
//                            'vaksins'=>vaksin::all()
//     ]);
// });

// Route::get('/pasien', function () {
//     return view('pasien', ['title'=>'Pasien',
//                            'Pasien'=>Pasien::all()
//   ]);
// });

Route::get('/contact', function () {
    return view('contact', ['title'=>'Contact',
                            'image'=>'contacticon.png']);
});

