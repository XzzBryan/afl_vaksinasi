<!DOCTYPE html>
<html lang="en">
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
    
    <title><?php echo $__env->yieldContent("title"); ?></title>

</head>
<body>
    <?php echo $__env->make('layout.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container pt-10">
    
        <?php echo $__env->yieldContent('main_content'); ?>

        <nav class="navbar navbar-expand-sm bg-light fixed-bottom justify corner navbar-light">
            copyright project catalog © <?php echo $__env->yieldContent('tahun'); ?>
        </nav>
        
    </div>

</body>
</html><?php /**PATH C:\laragon\www\vaksin\resources\views/layout/mainlayout.blade.php ENDPATH**/ ?>