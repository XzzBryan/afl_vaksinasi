

    <div class="container">
    <h1> <?php echo e($title); ?> </h1>
    </div>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Edit vaksin</title>
    <h1>Edit Vaksin</h1>
</head>
<body>
<div class="container">
    <form action="<?php echo e(route('vaksin.update', $vaksin->id)); ?>" method="post">
      <?php echo e(csrf_field()); ?>

      <input type="hidden" name="_method" value="PATCH">
<div class="form-group">
      <label>Vaksin Code: </label><br>
       <input type="text" name="vaksincode" value="<?php echo e($vaksin->code); ?>" required><br>
       <label> Vaksin Name : </label><br>  
       <input type="text" name="vaksinname"><br>
      <label> Efektifitas : </label><br>  
       <input type="text" name="efektif"><br>
      <label> Pembuat : </label><br>
       <input type="text" name="pembuat"><br>
       <label> Deskripsi : </label><br>
       <input type="text" name="deskripsi"><br>
        <input type="submit"><br>
      </form>
</div>

</body>
</html>

<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\vaksin\resources\views/editvaksin.blade.php ENDPATH**/ ?>