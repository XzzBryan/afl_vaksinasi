

    <div class="container">
    <h1> <?php echo e($title); ?> </h1>
    </div>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Formulir Vaksin</title>
    <h1>Input Data Vaksin Baru</h1>
</head>
<body>
<div class="container">
    <form action="<?php echo e(route('vaksin.store')); ?>"  method="post">
      <?php echo e(csrf_field()); ?>

      <label>Vaksin Code : </label><br>
      <input type="text" name="vaksin_code"><br>
       <label>Code : </label><br>
       <input type="text" name="code"><br>
       <label>Nama : </label><br>
       <input type="text" name="vaksin_name"><br>
       <label>Efektifitas : </label><br>
       <input type="text" name="efektifitas"><br>
       <label>Pembuat : </label><br>
       <input type="text" name="pembuat"><br>
       <label>Deskripsi : </label><br>
       <input type="text" name="deskripsi"><br> 
        <input type="submit"><br>
      </form>
      <?php if($errors->any()): ?>
      <div class="alert alert-danger">
        <ul>
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><?php echo e($error); ?></li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
      <?php endif; ?>
    <?php


if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // collect value of input field
  $name = $_POST['vaksin_code'];
  if (empty($vaksin_code)) {
    echo "Vaksin Code is empty";
  } else {
    echo $vaksin_code;  
  }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // collect value of input field
  $name = $_POST['vaksin_name'];
  if (empty($vaksin_name)) {
    echo "Vaksin name is empty";
  } else {
    echo $vaksin_name;  
  }
}

elseif ($_SERVER["REQUEST_METHOD"] == "POST") {
  // collect value of input field
  $name = $_POST['efektifitas'];
  if (empty($efektifitas)) {
    echo "Efektifitas Field is empty";
  } else {
    echo $efektifitas;  
  }
}

elseif ($_SERVER["REQUEST_METHOD"] == "POST") {
  // collect value of input field
  $name = $_POST['pembuat'];
  if (empty($pembuat)) {
    echo "Pembuat Field is empty";
  } else {
    echo $pembuat;  
  }
}

elseif ($_SERVER["REQUEST_METHOD"] == "POST") {
  // collect value of input field
  $name = $_POST['deskripsi'];
  if (empty($deskripsi)) {
    echo "Description Field is empty";
  } else {
    echo $deskripsi;  
  }
}

?>
    
</body>
</html>
<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\vaksin\resources\views/createvaksin.blade.php ENDPATH**/ ?>