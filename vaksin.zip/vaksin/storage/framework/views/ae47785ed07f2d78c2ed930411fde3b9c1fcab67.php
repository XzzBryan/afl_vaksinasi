


<div class="text-right">
    <title>Daftar Vaksin</title>
    <h1><?php echo e($title); ?></h1>
    <a class="btn btn-success pull-right" href="<?php echo e(route('vaksin.create')); ?>">
        <i class="fas fa-arrow-alt-circle-right"></i>Tambah Vaksin</a>
    </div>
<h2 class="text-center"><?php echo e($title); ?></h2>

<div class="container mt-3">  
    <table class="table table-light table-striped">
    <tr>
        <th>id</th>
        <th>Code</th>
        <th>Nama Vaksin</th>
        <th>Efektifitas</th>
        <th>Pembuat</th>
        <th>Deskripsi Singkat</th>
        <th class="text-center">•</th>
        <th class="text-center">•</th>
        <th class="text-center">•</th>
    </tr>


    <?php $__currentLoopData = $vaksin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vak): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<tr>
      <td> <?php echo e($vak['vaksincode']); ?></td>
      <td> <?php echo e($vak['code']); ?></td>
      <td> <?php echo e($vak['vaksin_name']); ?></td>
      <td> <?php echo e($vak['efektifitas']); ?></td>
      <td> <?php echo e($vak['pembuat']); ?></td>
      <td> <?php echo e($vak['deskripsi']); ?></td>

     <td class="text-center">   
    <form action="" method="POST">
   <a class="btn btn-success"  href="<?php echo e(route('vaksin.show', $vak->code)); ?>">Show</a>
    </form>
     </td>

   <td class="text-center">
    <form action="" method="POST">
   <a class="btn btn-warning"  href="<?php echo e(route('vaksin.edit', $vak->vaksincode)); ?>">Edit</a>
    </form>
   </td>

   <td class="text-center">
    <form action="<?php echo e(route('vaksin.destroy', $vak->vaksincode)); ?>" method="POST">
<?php echo csrf_field(); ?>
<?php echo method_field('DELETE'); ?>
<button type="submit" class="btn btn-danger">Delete</button>
    </form>
   </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>

<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\vaksin\resources\views/vaksin.blade.php ENDPATH**/ ?>