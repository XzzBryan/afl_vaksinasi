

<h1>test</h1>

<div class="mt-4 p-5 bg-primary text-white rounded">
    <h1><?php echo e($pasien['id']); ?></h1>
    <p>Pasien : <?php echo e($pasien['pasien_name']); ?></p>
    <p>Dokter : <?php echo e($pasien['penyuntik']); ?></p>
    </div>



<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\vaksin\resources\views/showpasien.blade.php ENDPATH**/ ?>