

    <div class="container">
    <h1> <?php echo e($title); ?> </h1>
    </div>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Edit Pasien</title>
    <h1>Edit Pasien</h1>
</head>
<body>
<div class="container">
    <form action="<?php echo e(route('pasien.update', $pasien->id)); ?>" method="post">
      <?php echo e(csrf_field()); ?>

      <input type="hidden" name="_method" value="PATCH">
<div class="form-group">
      <label>Pasien Code : </label><br>
       <input type="text" name="pasiencode" value="<?php echo e($pasien->id); ?>" required><br>
       <label> Nama Pasien : </label><br>  
       <input type="text" name="pasienname"><br>
      <label> Penyuntik : </label><br>  
       <input type="text" name="penyuntik"><br>
      <label> Jumlah : </label><br>
       <input type="text" name="jumlah"><br>
       <label> Vaksin : </label><br>
       <input type="text" name="vaksinname"><br>
       <label> Gejala : </label><br>
       <input type="text" name="gejala"><br>
       <label> Deskripsi : </label><br>
       <input type="text" name="deskripsi"><br>
        <input type="submit" value="Update"><br>
      </form>
</div>

</body>
</html>

<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\vaksin\resources\views/editpasien.blade.php ENDPATH**/ ?>