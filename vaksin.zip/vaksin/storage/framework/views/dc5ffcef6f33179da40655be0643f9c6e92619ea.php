

<div class="text-right">
    <title>Daftar Pasien</title>
    <h1><?php echo e($title); ?></h1>
</div>
    <div class="text-right">
    <a class="btn btn-success pull-right" href="<?php echo e(route('pasien.create')); ?>">
        <i class="fas fa-arrow-alt-circle-right"></i>Daftar Pasien</a>
    </div>

<h2 class="text-center"><?php echo e($title); ?></h2>
 


<!--KONTAINER-->
<div class="container mt-3">  
    <table class="table table-light table-striped">
    <tr>
        <th>id</th> 
        <th>Nama</th>
        <th>Penyuntik</th>
        <th>Dosis ke</th>
        <th>Vaksin</th>
        <th>Gejala</th>
        <th>Deskripsi</th>
        <th class="text-center">•</th>
        <th class="text-center">•</th>
        <th class="text-center">•</th>
    </tr>
    

<?php $__currentLoopData = $pasien; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<tr>
      <td> <?php echo e($pas['id']); ?></td>
      <td> <?php echo e($pas['pasien_name']); ?></td>
      <td> <?php echo e($pas['penyuntik']); ?></td>
      <td> <?php echo e($pas['jumlah']); ?></td>
      <td> <?php echo e($pas['nama_vaksin']); ?></td>
      <td> <?php echo e($pas['gejala']); ?></td>
      <td> <?php echo e($pas['deskripsi']); ?></td>

     <td class="text-center">
    <form action="" method="POST">
   <a class="btn btn-success"  href="<?php echo e(route('pasien.show', $pas->id)); ?>">Show</a>
    </form>
     </td>

   <td class="text-center">
   <a class="btn btn-warning"  href="<?php echo e(route('pasien.edit', $pas->id)); ?>">Edit</a>
   </td>
   
   <td class="text-center">
    <form action="<?php echo e(route('pasien.destroy', $pas->id)); ?>" method="POST">
<?php echo csrf_field(); ?>
<?php echo method_field('DELETE'); ?>
<button type="submit" class="btn btn-danger">Delete</button>
    </form>
   </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>


<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\vaksin\resources\views/pasien.blade.php ENDPATH**/ ?>