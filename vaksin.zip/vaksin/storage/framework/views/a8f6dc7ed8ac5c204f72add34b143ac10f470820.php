

<h1>test</h1>

<div class="mt-4 p-5 bg-warning text-dark rounded">
    <h1><?php echo e($vaksin['vaksin_name']); ?></h1>
    <p>Efektifitas : <?php echo e($vaksin['efektifitas']); ?></p>
    <p>Pembuat : <?php echo e($vaksin['pembuat']); ?></p>
    <p>Code : <?php echo e($vaksin['code']); ?></p>
    </div>



<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\vaksin\resources\views/showvaksin.blade.php ENDPATH**/ ?>