


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" conte nt="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e($title); ?></title>
    <h1><?php echo e($title); ?></h1>
    <h1 class="text-center"><?php echo e($title); ?></h1>
    <p class="text-center"><strong>Program Vaksinasi COVID-19 didukung oleh pemerintah secara gratis, dengan demikian masyarakat diharapkan segera melakukan pendaftaran di dareah terdekat.</strong></p><br>
    <p class="text-center"><em>Vaksinasi adalah proses pemberian vaksin ke dalam tubuh. Bila seseorang sudah mendapat vaksin untuk suatu penyakit,</em></p>
    <p class="text-center"><em>tubuhnya bisa dengan cepat membentuk antibodi untuk melawan kuman atau virus penyebab penyakit tersebut ketika nanti ia terpapar.</em></p><br><br><br>
</head>
<body>

    <center><div class="row">
        <div class="col-sm-6">
          <div class="card">
            <div class="card-body bg-warning text-dark rounded">
              <h5 class="card-title">Tentang Virus Covid-19</h5>
              <p class="card-text">Everything About Covid-19 Are Available Here</p>
              <a href="https://en.wikipedia.org/wiki/COVID-19" class="btn btn-primary">About Covid-19</a>
            </div>
          </div>
        </div>
        <div class="col-sm-6">
          <div class="card">
            <div class="card-body bg-warning text-dark rounded">
              <h5 class="card-title">Tips Pencegahan Covid</h5>
              <p class="card-text">Some Tips to Prevent Contracting the Corona Virus</p>
              <a href="https://www.alodokter.com/ketahui-cara-untuk-mencegah-penularan-virus-corona" class="btn btn-primary">About Tips</a>
            </div>
          </div>
        </div>
      </div></center>

    <div class="has-bg-img bg-purple bg-blend-overlay no-repeat center center fixed">
        <center><img src="img/<?php echo e($image); ?>" alt="Dawn Winery" width="90%"></center>
      </div>
    
      
</body>
</html>
<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\vaksin\resources\views/home.blade.php ENDPATH**/ ?>