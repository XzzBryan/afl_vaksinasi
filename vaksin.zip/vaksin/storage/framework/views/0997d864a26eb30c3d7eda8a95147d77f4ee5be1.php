<nav class="navbar navbar-expand-sm bg-danger navbar-dark fixed-top">
    <div class="container-fluid">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link <?php echo e(($title==="Home")?'active':''); ?>" href="/">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?php echo e(($title==="About")?'active':''); ?>" href="/about">About</a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?php echo e(($title==="Vaksin")?'active':''); ?>" href="/vaksin">Vaksin</a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?php echo e(($title==="Pasien")?'active':''); ?>" href="/pasien">Pasien</a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?php echo e(($title==="Contact")?'active':''); ?>" href="/contact">Contact</a>
        </li>
      </ul>
    </div>
  </nav>
  
  <?php /**PATH C:\laragon\www\vaksin\resources\views/layout/navigation.blade.php ENDPATH**/ ?>