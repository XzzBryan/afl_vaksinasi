<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class VaksinSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('vaksins')->insert([
            'vaksin_name'=>'Sinovac',
            'code'=>'Sin',
            'efektifitas'=>'70%',
            'pembuat'=>'Pt.kimia farma',
            'deskripsi'=>'Lorem ipsum dolor sit amet',
            'created_at'=> \Carbon\Carbon::now(),
            'updated_at'=> \Carbon\Carbon::now()
        ]);

        DB::table('vaksins')->insert([
            'vaksin_name'=>'Astrazeneca',
            'code'=>'Ast',
            'efektifitas'=>'80%',
            'pembuat'=>'Pt.petrojaya',
            'deskripsi'=>'Lorem ipsum dolor sit amet',
            'created_at'=> \Carbon\Carbon::now(),
            'updated_at'=> \Carbon\Carbon::now()
        ]);
        
        DB::table('vaksins')->insert([
            'vaksin_name'=>'Moderna',
            'code'=>'Mod',
            'efektifitas'=>'90%',
            'pembuat'=>'Pt.Perindo',
            'deskripsi'=>'Lorem ipsum dolor sit amet',
            'created_at'=> \Carbon\Carbon::now(),
            'updated_at'=> \Carbon\Carbon::now()
        ]); 

        DB::table('vaksins')->insert([
            'vaksin_name'=>'Sputnik',
            'code'=>'Spu',
            'efektifitas'=>'77%',
            'pembuat'=>'Rusia (Gamaleya Research Institute)',
            'deskripsi'=>'Lorem ipsum dolor sit amet',
            'created_at'=> \Carbon\Carbon::now(),
            'updated_at'=> \Carbon\Carbon::now()
        ]); 

        DB::table('vaksins')->insert([
            'vaksin_name'=>'CanSino',
            'code'=>'Can',
            'efektifitas'=>'81%',
            'pembuat'=>'Beijing (CanSino Biological Institute Inc)',
            'deskripsi'=>'Lorem ipsum dolor sit amet',
            'created_at'=> \Carbon\Carbon::now(),
            'updated_at'=> \Carbon\Carbon::now()
        ]); 


    }
}
