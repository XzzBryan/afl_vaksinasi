<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class PasienSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('pasiens')->insert([
            'pasien_name'=>'Bryan',
            'penyuntik'=>'Dr.Budi',
            'jumlah'=>'2',
            'nama_vaksin'=>'1',
            'gejala'=>'Tidak ada',
            'deskripsi'=>'Lorem ipsum dolor sit amet',
            'created_at'=> \Carbon\Carbon::now(),
            'updated_at'=> \Carbon\Carbon::now()
        ]);

        DB::table('pasiens')->insert([
            'pasien_name'=>'Felix',
            'penyuntik'=>'Dr.Rudy',
            'jumlah'=>'1',
            'nama_vaksin'=>'2',
            'gejala'=>'Pilek',
            'deskripsi'=>'Lorem ipsum dolor sit amet',
            'created_at'=> \Carbon\Carbon::now(),
            'updated_at'=> \Carbon\Carbon::now()
        ]);
        
        DB::table('pasiens')->insert([
            'pasien_name'=>'Alfred',
            'penyuntik'=>'Dr.Mudi',
            'jumlah'=>'2',
            'nama_vaksin'=>'3',
            'gejala'=>'Batuk',
            'deskripsi'=>'Lorem ipsum dolor sit amet',
            'created_at'=> \Carbon\Carbon::now(),
            'updated_at'=> \Carbon\Carbon::now()
        ]); 


    }
}
