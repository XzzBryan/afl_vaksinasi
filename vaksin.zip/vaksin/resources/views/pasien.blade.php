@extends('layout.mainlayout')

<div class="text-right">
    <title>Daftar Pasien</title>
    <h1>{{ $title }}</h1>
</div>
    <div class="text-right">
    <a class="btn btn-success pull-right" href="{{ route('pasien.create') }}">
        <i class="fas fa-arrow-alt-circle-right"></i>Daftar Pasien</a>
    </div>

<h2 class="text-center">{{ $title }}</h2>
 


<!--KONTAINER-->
<div class="container mt-3">  
    <table class="table table-light table-striped">
    <tr>
        <th>id</th> 
        <th>Nama</th>
        <th>Penyuntik</th>
        <th>Dosis ke</th>
        <th>Vaksin</th>
        <th>Gejala</th>
        <th>Deskripsi</th>
        <th class="text-center">•</th>
        <th class="text-center">•</th>
        <th class="text-center">•</th>
    </tr>
    

@foreach ($pasien as $pas)

<tr>
      <td> {{ $pas['id'] }}</td>
      <td> {{ $pas['pasien_name'] }}</td>
      <td> {{ $pas['penyuntik'] }}</td>
      <td> {{ $pas['jumlah'] }}</td>
      <td> {{ $pas['nama_vaksin'] }}</td>
      <td> {{ $pas['gejala'] }}</td>
      <td> {{ $pas['deskripsi'] }}</td>

     <td class="text-center">
    <form action="" method="POST">
   <a class="btn btn-success"  href="{{ route('pasien.show', $pas->id) }}">Show</a>
    </form>
     </td>

   <td class="text-center">
   <a class="btn btn-warning"  href="{{ route('pasien.edit', $pas->id) }}">Edit</a>
   </td>
   
   <td class="text-center">
    <form action="{{ route('pasien.destroy', $pas->id) }}" method="POST">
@csrf
@method('DELETE')
<button type="submit" class="btn btn-danger">Delete</button>
    </form>
   </td>
</tr>
@endforeach

</table>

