@extends('layout.mainlayout')

<h1>test</h1>

<div class="mt-4 p-5 bg-primary text-white rounded">
    <h1>{{ $pasien['id'] }}</h1>
    <p>Pasien : {{ $pasien['pasien_name'] }}</p>
    <p>Dokter : {{ $pasien['penyuntik'] }}</p>
    </div>


