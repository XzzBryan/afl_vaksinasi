<nav class="navbar navbar-expand-sm bg-danger navbar-dark fixed-top">
    <div class="container-fluid">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link {{($title==="Home")?'active':''}}" href="/">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link {{($title==="About")?'active':''}}" href="/about">About</a>
        </li>
        <li class="nav-item">
          <a class="nav-link {{($title==="Vaksin")?'active':''}}" href="/vaksin">Vaksin</a>
        </li>
        <li class="nav-item">
          <a class="nav-link {{($title==="Pasien")?'active':''}}" href="/pasien">Pasien</a>
        </li>
        <li class="nav-item">
          <a class="nav-link {{($title==="Contact")?'active':''}}" href="/contact">Contact</a>
        </li>
      </ul>
    </div>
  </nav>
  
  