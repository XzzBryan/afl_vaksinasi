@extends('layout.mainlayout')

    <div class="container">
    <h1> {{ $title }} </h1>
    </div>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Formulir Vaksin</title>
    <h1>Input Data Vaksin Baru</h1>
</head>
<body>
<div class="container">
    <form action="{{ route('vaksin.store') }}"  method="post">
      {{ csrf_field() }}
      <label>Vaksin Code : </label><br>
      <input type="text" name="vaksin_code"><br>
       <label>Code : </label><br>
       <input type="text" name="code"><br>
       <label>Nama : </label><br>
       <input type="text" name="vaksin_name"><br>
       <label>Efektifitas : </label><br>
       <input type="text" name="efektifitas"><br>
       <label>Pembuat : </label><br>
       <input type="text" name="pembuat"><br>
       <label>Deskripsi : </label><br>
       <input type="text" name="deskripsi"><br> 
        <input type="submit"><br>
      </form>
      @if ($errors->any())
      <div class="alert alert-danger">
        <ul>
          @foreach ($errors->all() as $error)
          <li>{{ $error }}</li>
          @endforeach
        </ul>
      </div>
      @endif
    <?php


if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // collect value of input field
  $name = $_POST['vaksin_code'];
  if (empty($vaksin_code)) {
    echo "Vaksin Code is empty";
  } else {
    echo $vaksin_code;  
  }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // collect value of input field
  $name = $_POST['vaksin_name'];
  if (empty($vaksin_name)) {
    echo "Vaksin name is empty";
  } else {
    echo $vaksin_name;  
  }
}

elseif ($_SERVER["REQUEST_METHOD"] == "POST") {
  // collect value of input field
  $name = $_POST['efektifitas'];
  if (empty($efektifitas)) {
    echo "Efektifitas Field is empty";
  } else {
    echo $efektifitas;  
  }
}

elseif ($_SERVER["REQUEST_METHOD"] == "POST") {
  // collect value of input field
  $name = $_POST['pembuat'];
  if (empty($pembuat)) {
    echo "Pembuat Field is empty";
  } else {
    echo $pembuat;  
  }
}

elseif ($_SERVER["REQUEST_METHOD"] == "POST") {
  // collect value of input field
  $name = $_POST['deskripsi'];
  if (empty($deskripsi)) {
    echo "Description Field is empty";
  } else {
    echo $deskripsi;  
  }
}

?>
    
</body>
</html>