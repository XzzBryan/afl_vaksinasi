@extends('layout.mainlayout')

<h1>test</h1>

<div class="mt-4 p-5 bg-warning text-dark rounded">
    <h1>{{ $vaksin['vaksin_name'] }}</h1>
    <p>Efektifitas : {{ $vaksin['efektifitas'] }}</p>
    <p>Pembuat : {{ $vaksin['pembuat'] }}</p>
    <p>Code : {{ $vaksin['code'] }}</p>
    </div>


