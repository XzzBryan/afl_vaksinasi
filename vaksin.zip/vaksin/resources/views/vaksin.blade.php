@extends('layout.mainlayout')


<div class="text-right">
    <title>Daftar Vaksin</title>
    <h1>{{ $title }}</h1>
    <a class="btn btn-success pull-right" href="{{ route('vaksin.create') }}">
        <i class="fas fa-arrow-alt-circle-right"></i>Tambah Vaksin</a>
    </div>
<h2 class="text-center">{{ $title }}</h2>

<div class="container mt-3">  
    <table class="table table-light table-striped">
    <tr>
        <th>id</th>
        <th>Code</th>
        <th>Nama Vaksin</th>
        <th>Efektifitas</th>
        <th>Pembuat</th>
        <th>Deskripsi Singkat</th>
        <th class="text-center">•</th>
        <th class="text-center">•</th>
        <th class="text-center">•</th>
    </tr>


    @foreach ($vaksin as $vak)

<tr>
      <td> {{ $vak['vaksincode'] }}</td>
      <td> {{ $vak['code'] }}</td>
      <td> {{ $vak['vaksin_name'] }}</td>
      <td> {{ $vak['efektifitas'] }}</td>
      <td> {{ $vak['pembuat'] }}</td>
      <td> {{ $vak['deskripsi'] }}</td>

     <td class="text-center">   
    <form action="" method="POST">
   <a class="btn btn-success"  href="{{ route('vaksin.show', $vak->code) }}">Show</a>
    </form>
     </td>

   <td class="text-center">
    <form action="" method="POST">
   <a class="btn btn-warning"  href="{{ route('vaksin.edit', $vak->vaksincode) }}">Edit</a>
    </form>
   </td>

   <td class="text-center">
    <form action="{{ route('vaksin.destroy', $vak->vaksincode) }}" method="POST">
@csrf
@method('DELETE')
<button type="submit" class="btn btn-danger">Delete</button>
    </form>
   </td>
</tr>
@endforeach

</table>
