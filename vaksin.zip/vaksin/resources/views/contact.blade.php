@extends('layout.mainlayout')

<!DOCTYPE html>
<html lang="en">
<head>
  <div class="p-3 mb-2 bg-info text-dark">.bg-info</div>
  <div class="p-3 mb-2 bg-warning text-dark">
    <title>{{ $title }}</title>
  
    <h1 class="text-center">{{ $title }}</h1>
    <p class="text-center"><strong>Info terkait Informasi kami ada disini</strong></p><br>
    <p class="text-center"><em>Hubungi kami di 081231209278</em></p>
    <p class="text-center"><em>Email kami :</em><a href="mailto:bryananthony872@gmail.com?subject"> Bryananthony872@gmail.com</a></p>
</head>
<body>

  <center><img src="img/{{ $image }}" alt="Vaccine image" width="200" class="img-thumbnail rounded-circle" ></center>
  </div>
  
</body>
</html>

    
