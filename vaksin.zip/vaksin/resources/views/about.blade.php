@extends('layout.mainlayout')

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" conte nt="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>{{ $title }}</title>
    <h1>{{ $title }}</h1>
    <h1 class="text-center">{{ $title }}</h1>
    <p class="text-center"><strong>Website ini hanya menyediakan layanan informasi dan pendaftaran terkait Vaksin Covid-19</strong></p><br>
    <p class="text-center"><em>Untuk melihat Daftar vaksin yang tersedia bisa klik disini</em><a href="/vaksin"> Click</a></p>
    <p class="text-center"><em>Untuk informasi atau bantuan lebih lanjut bisa klik disini</em><a href="/contact"> Click</a></p>
</head>
<body>

  <center><img src="img/{{ $image }}" alt="Vaccine image" width="200" class="img-thumbnail rounded-circle" ></center>
  </div>

  <div class="container">
    <style>
        #more {display: none;}
    </style>
    <h1 class="text-center">Welcome to Vaksinasi Hub</h1><br>

   <center> <h5>What can we do with this website<span id="dots">...</span><span id="more">
Pada website ini saya membuat fitur CRUD untuk program pendaftaran Vaksin & Pasien, Selamat menjelajahi dan Memikmati konten Kami, Bila ada saran bisa langsung menghubungi kami 
pada halaman Contact, terimakasih sudah berkunjung :D</span></h5>
    <button onclick="myFunction()" id="myBtn">Read more</button></center>

    <script>
    function myFunction() {
    var dots = document.getElementById("dots");
    var moreText = document.getElementById("more");
    var btnText = document.getElementById("myBtn");

        if (dots.style.display === "none") {
            dots.style.display = "inline";
            btnText.innerHTML = "Read more"; 
            moreText.style.display = "none";
        } else {
            dots.style.display = "none";
            btnText.innerHTML = "Read less"; 
            moreText.style.display = "inline";
        }
        }
        </script>
        </div>
  
</body>
</html>