@extends('layout.mainlayout')

    <div class="container">
    <h1> {{ $title }} </h1>
    </div>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Edit vaksin</title>
    <h1>Edit Vaksin</h1>
</head>
<body>
<div class="container">
    <form action="{{ route('vaksin.update', $vaksin->vaksincode) }}" method="post">
      {{ csrf_field() }}
      <input type="hidden" name="_method" value="PATCH">
<div class="form-group">
      <label>Vaksin Code: </label><br>
       <input type="text" name="vaksincode" value="{{ $vaksin->vaksincode }}" required><br>
       <label> Code : </label><br>  
       <input type="text" name="code"><br>
       <label> Vaksin Name : </label><br>  
       <input type="text" name="vaksinname"><br>
      <label> Efektifitas : </label><br>  
       <input type="text" name="efektif"><br>
      <label> Pembuat : </label><br>
       <input type="text" name="pembuat"><br>
       <label> Deskripsi : </label><br>
       <input type="text" name="deskripsi"><br>
        <input type="submit"><br>
      </form>
</div>

</body>
</html>
