@extends('layout.mainlayout')

    <div class="container">
    <h1> {{ $title }} </h1>
    </div>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Formulir Pasien</title>
    <h1>Input Data Baru Pasien</h1>
</head>
<body>
<div class="container">
    <form action="{{ route('pasien.store') }}"  method="post">
      {{ csrf_field() }}
       <label>Nama : </label><br>
       <input type="text" name="pasien_name"><br>
       <label>Penyuntik : </label><br>
       <input type="text" name="penyuntik"><br>
       <label>Dosis ke : </label><br>
       <input type="text" name="jumlah"><br>
       <label>Nama Vaksin : </label><br>
       <input type="text" name="nama_vaksin"><br> 
       <label>Gejala : </label><br>
       <input type="text" name="gejala"><br> 
       <label>Deskripsi : </label><br>
       <input type="text" name="deskripsi"><br> 
        <input type="submit"><br>
      </form>
      @if ($errors->any())
      <div class="alert alert-danger">
        <ul>
          @foreach ($errors->all() as $error)
          <li>{{ $error }}</li>
          @endforeach
        </ul>
      </div>
      @endif
    <?php


if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // collect value of input field
  $name = $_POST['pasien_name'];
  if (empty($pasien_name)) {
    echo "Pasien name is empty";
  } else {
    echo $pasien_name;  
  }
}

elseif ($_SERVER["REQUEST_METHOD"] == "POST") {
  // collect value of input field
  $name = $_POST['penyuntik'];
  if (empty($penyuntik)) {
    echo "Penyuntik is empty";
  } else {
    echo $penyuntik;  
  }
}

elseif ($_SERVER["REQUEST_METHOD"] == "POST") {
  // collect value of input field
  $name = $_POST['jumlah'];
  if (empty($jumlah)) {
    echo "Jumlah dosis is empty";
  } else {
    echo $jumlah;  
  }
}

elseif ($_SERVER["REQUEST_METHOD"] == "POST") {
  // collect value of input field
  $name = $_POST['nama_vaksin'];
  if (empty($nama_vaksin)) {
    echo "Vaksin name is empty";
  } else {
    echo $nama_vaksin;  
  }
}

elseif ($_SERVER["REQUEST_METHOD"] == "POST") {
  // collect value of input field
  $name = $_POST['gejala'];
  if (empty($gejala)) {
    echo "Gejala is empty";
  } else {
    echo $gejala;  
  }
}

elseif ($_SERVER["REQUEST_METHOD"] == "POST") {
  // collect value of input field
  $name = $_POST['deskripsi'];
  if (empty($deskripsi)) {
    echo "Description is empty";
  } else {
    echo $deskripsi;  
  }
}

?>
    
</body>
</html>